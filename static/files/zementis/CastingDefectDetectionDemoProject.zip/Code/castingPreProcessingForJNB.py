import numpy as np
from PIL import Image
import io
def process(content):
    im = Image.open(io.BytesIO(content)).convert('RGB')
    im = im.resize((224,224))
    x = np.array(im,dtype=np.float32)
    x *= 1./255
    x = np.expand_dims(x,0)
    return {"input_1":x}
