def process(content):
    import numpy as np
    classes = ["defective","ok"]
    cla = classes[np.argmax(content[0])]
    return {"ProbabilityScore":content[0].tolist(),"PredictedClass":cla}